"""Week 4: Predictive modeling and optimization for a hypothetical logistics network.
Target: actual delivery time in days. Then: promise-time buffer policy and LP carrier allocation."""
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import linprog
from sklearn.model_selection import train_test_split, KFold, cross_val_score, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, RandomForestClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sns.set_theme(style="whitegrid", context="notebook")
SEED = 11

# ---------- 1. Data simulation (same generator as Week 3) ----------
def simulate(n=6000, seed=SEED):
    rng = np.random.default_rng(seed)
    dates = pd.Timestamp("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n), unit="D")
    df = pd.DataFrame({
        "shipment_id": np.arange(1, n + 1), "ship_date": dates,
        "origin_hub": rng.choice(["Delhi", "Mumbai", "Chennai", "Kolkata"], n, p=[.32, .3, .22, .16]),
        "dest_region": rng.choice(["North", "South", "East", "West", "Central"], n, p=[.25, .25, .15, .2, .15]),
        "mode": rng.choice(["Road", "Rail", "Air"], n, p=[.62, .26, .12]),
        "carrier": rng.choice(["Carrier A", "Carrier B", "Carrier C", "Carrier D"], n, p=[.35, .3, .2, .15]),
    })
    df["distance_km"] = rng.gamma(4, 260, n).clip(60, 3200).round(0)
    df["weight_kg"] = rng.lognormal(5.2, .8, n).clip(5, 4000).round(1)
    speed = df["mode"].map({"Road": 450, "Rail": 380, "Air": 1500})
    df["scheduled_days"] = np.ceil(df["distance_km"] / speed + df["mode"].map({"Road": 0.6, "Rail": 1.4, "Air": 0.3})).astype(int)
    m = df["ship_date"].dt.month
    peak = np.where(m.isin([10, 11, 12]), 0.9, 0.0)
    carrier_delay = df["carrier"].map({"Carrier A": 0.1, "Carrier B": 0.25, "Carrier C": 0.9, "Carrier D": 0.35})
    region_delay = df["dest_region"].map({"North": 0.2, "South": 0.1, "East": 0.8, "West": 0.15, "Central": 0.4})
    delay = rng.gamma(1.4, 0.55, n) * (0.5 + carrier_delay + region_delay + peak) - 0.55
    df["actual_days"] = np.maximum(1, np.round(df["scheduled_days"] + delay)).astype(int)
    rate = df["mode"].map({"Road": 3.1, "Rail": 2.0, "Air": 11.5})
    df["freight_cost"] = (df["distance_km"] * (df["weight_kg"] / 1000) * rate * rng.normal(1, .08, n) + 450).round(0)
    df["fuel_surcharge_pct"] = (rng.normal(9, 2, n) + (m.isin([10, 11, 12, 1]) * 2)).clip(2, 20).round(1)
    df["dwell_hours"] = (rng.gamma(2.2, 4, n) * (1 + 0.45 * (df["origin_hub"] == "Mumbai") + 0.35 * m.isin([10, 11, 12]))).round(1)
    return df

# ---------- 2. Problem definition and feature preparation ----------
# Target: actual_days. Features are only things known when the shipment is booked.
# dwell_hours is NOT used: it is only known after the shipment has waited at the hub (data leakage).
CAT = ["origin_hub", "dest_region", "mode", "carrier"]
NUM = ["distance_km", "weight_kg", "scheduled_days", "fuel_surcharge_pct", "month_num"]
TARGET = "actual_days"

def prepare(df):
    df = df.copy()
    df["month_num"] = df["ship_date"].dt.month
    df["is_late"] = (df["actual_days"] > df["scheduled_days"]).astype(int)
    return df

def preprocessor():
    return ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), CAT), ("num", "passthrough", NUM)])

def metrics(y, p):
    return dict(MAE=mean_absolute_error(y, p), RMSE=np.sqrt(mean_squared_error(y, p)), R2=r2_score(y, p))

# ---------- 3. Model training, comparison and cross-validation ----------
def compare_models(Xtr, ytr, Xte, yte):
    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=6, random_state=SEED),
        "Random Forest": RandomForestRegressor(n_estimators=200, min_samples_leaf=5, random_state=SEED, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(random_state=SEED),
        "GB (MAE loss)": GradientBoostingRegressor(loss="absolute_error", random_state=SEED),
    }
    kf = KFold(5, shuffle=True, random_state=SEED)
    rows, fitted = [], {}
    base = metrics(yte, Xte["scheduled_days"])
    rows.append(dict(Model="Baseline: scheduled days", CV_MAE=np.nan, **{"Test_" + k: v for k, v in base.items()}))
    for name, mdl in models.items():
        pipe = Pipeline([("prep", preprocessor()), ("model", mdl)])
        cv = -cross_val_score(pipe, Xtr, ytr, cv=kf, scoring="neg_mean_absolute_error")
        pipe.fit(Xtr, ytr); fitted[name] = pipe
        t = metrics(yte, pipe.predict(Xte))
        rows.append(dict(Model=name, CV_MAE=cv.mean(), **{"Test_" + k: v for k, v in t.items()}))
        print(f"{name:18s} 5-fold CV MAE per fold: {np.round(cv, 3)}")
    res = pd.DataFrame(rows).round(3)
    print("\n=== Model comparison (test set, 1,200 shipments) ===")
    print(res.to_string(index=False))
    return res, fitted

# ---------- 4. Hyperparameter tuning ----------
def tune(Xtr, ytr, Xte, yte):
    pipe = Pipeline([("prep", preprocessor()), ("model", GradientBoostingRegressor(random_state=SEED))])
    grid = {"model__n_estimators": [100, 200], "model__max_depth": [2, 3, 4], "model__learning_rate": [0.05, 0.1]}
    gs = GridSearchCV(pipe, grid, cv=KFold(5, shuffle=True, random_state=SEED), scoring="neg_root_mean_squared_error", n_jobs=-1)
    gs.fit(Xtr, ytr)
    print("\n=== GridSearchCV (Gradient Boosting, 12 combinations x 5 folds) ===")
    print("Best parameters:", gs.best_params_, "| best CV RMSE: %.3f" % -gs.best_score_)
    t = metrics(yte, gs.predict(Xte))
    print("Tuned model on test set: MAE %.3f | RMSE %.3f | R2 %.3f" % (t["MAE"], t["RMSE"], t["R2"]))
    print("Same model with predictions rounded to whole days: MAE %.3f (delivery days are whole numbers)" % mean_absolute_error(yte, np.round(gs.predict(Xte))))
    print("Share of test shipments that arrived exactly on schedule: %.1f%%" % (100 * (yte == Xte["scheduled_days"]).mean()))
    return gs.best_estimator_

# ---------- 5. Feature importance and worked prediction ----------
def importance(model, Xte, yte):
    from sklearn.inspection import permutation_importance
    pi = permutation_importance(model, Xte, yte, n_repeats=10, random_state=SEED, scoring="neg_mean_absolute_error")
    imp = pd.Series(pi.importances_mean, index=Xte.columns).sort_values(ascending=False)
    print("\n=== Permutation importance (increase in MAE when the feature is shuffled) ===")
    print(imp.round(3).to_string())
    return imp

def worked_example(model, Xte, yte):
    row = Xte.iloc[[0]]
    print("\n=== Worked prediction example (first test shipment) ===")
    print(row.T.to_string(header=False))
    print("Scheduled days: %d | Model prediction: %.2f days | Actual: %d days" % (row.scheduled_days.iloc[0], model.predict(row)[0], yte.iloc[0]))

# ---------- 6. Optimization A: data-driven promise time ----------
def promise_policy(model, Xtr, ytr, Xte, yte):
    from sklearn.model_selection import cross_val_predict
    oof = cross_val_predict(model, Xtr, ytr, cv=KFold(5, shuffle=True, random_state=SEED))
    resid = ytr - oof
    print("\n=== Optimization A: promise time = ceil(prediction + buffer) ===")
    rows = []
    pred = model.predict(Xte)
    rows.append(dict(Policy="Current: scheduled days", AvgPromise=Xte.scheduled_days.mean(), OnTime=(yte <= Xte.scheduled_days).mean() * 100))
    for q in [0.5, 0.8, 0.9, 0.95]:
        buf = np.quantile(resid, q)
        promise = np.ceil(pred + buf)
        rows.append(dict(Policy=f"Predicted + {int(q*100)}th pct buffer ({buf:+.2f} d)", AvgPromise=promise.mean(), OnTime=(yte <= promise).mean() * 100))
    out = pd.DataFrame(rows).round(2)
    print(out.to_string(index=False))
    return out

# ---------- 7. Optimization B: linear programming carrier allocation ----------
def carrier_allocation(df, Xtr, Xte):
    from sklearn.metrics import roc_auc_score, accuracy_score
    clf = Pipeline([("prep", preprocessor()), ("model", RandomForestClassifier(n_estimators=200, min_samples_leaf=10, random_state=SEED, n_jobs=-1))])
    clf.fit(Xtr, df.loc[Xtr.index, "is_late"])
    yl = df.loc[Xte.index, "is_late"]; pl = clf.predict_proba(Xte)[:, 1]
    print("\n=== Late-delivery classifier (used by the optimizer), test set ===")
    print("Accuracy %.3f (always predicting 'on time' gives %.3f) | ROC AUC %.3f" % (accuracy_score(yl, pl > .5), 1 - yl.mean(), roc_auc_score(yl, pl)))
    df = df.assign(p_late=clf.predict_proba(df.loc[:, CAT + NUM])[:, 1])
    carriers = ["Carrier A", "Carrier B", "Carrier C", "Carrier D"]
    regions = ["Central", "East", "North", "South", "West"]
    demand = (df["dest_region"].value_counts(normalize=True).reindex(regions) * 1000).round(0)
    # Freight cost depends on distance, weight and mode (not on who the carrier is), so the cost of serving a region is the
    # region average, scaled by each carrier's price index (carrier cost per km / network cost per km).
    region_cost = df.groupby("dest_region")["freight_cost"].mean().reindex(regions)
    observed_idx = (df.groupby("carrier").apply(lambda g: g.freight_cost.sum() / g.distance_km.sum()) / (df.freight_cost.sum() / df.distance_km.sum())).reindex(carriers)
    print("Observed carrier price index (cost per km vs network):", observed_idx.round(3).to_dict(), "-> differences are small, so equal rate cards are assumed")
    price_idx = pd.Series(1.0, index=carriers)
    cost = pd.DataFrame(np.outer(price_idx.values, region_cost.values), index=carriers, columns=regions)
    plate = df.groupby(["carrier", "dest_region"])["p_late"].mean().unstack().reindex(index=carriers, columns=regions)
    print("\n=== Optimization B: LP carrier allocation (1,000 shipments per planning round) ===")
    print("Demand per region:", demand.astype(int).to_dict())
    print("Carrier price index:", price_idx.round(3).to_dict())
    print("\nPredicted late probability (carrier x region):"); print(plate.round(3).to_string())
    nC, nR = len(carriers), len(regions)
    cap = {"Carrier A": 450, "Carrier B": 350, "Carrier C": 200, "Carrier D": 200}   # carrier capacity per round
    share = pd.crosstab(df["carrier"], df["dest_region"], normalize="columns").reindex(index=carriers, columns=regions)
    cur = share * demand.values                                                       # current plan: historical shares
    def solve(PEN):
        c = (cost + PEN * plate).values.flatten()                                     # variable x[c, r], carrier-major
        A_eq = np.zeros((nR, nC * nR))
        for r in range(nR):
            for k in range(nC): A_eq[r, k * nR + r] = 1                               # each region's demand fully served
        A_ub = np.zeros((nC, nC * nR))
        for k in range(nC): A_ub[k, k * nR:(k + 1) * nR] = 1                          # carrier capacity
        bounds = [(0.05 * demand.values[r] if carriers[k] == "Carrier C" else 0, None) for k in range(nC) for r in range(nR)]  # C keeps 5% (contract)
        res = linprog(c, A_ub=A_ub, b_ub=[cap[k] for k in carriers], A_eq=A_eq, b_eq=demand.values, bounds=bounds, method="highs")
        return pd.DataFrame(res.x.reshape(nC, nR), index=carriers, columns=regions)
    def summarise(plan, PEN):
        late = (plan * plate).values.sum(); fr = (plan * cost).values.sum()
        return late, fr, fr + PEN * late
    PEN = 400.0     # assumed penalty per late shipment (rupees): refunds, rework, lost goodwill
    x = solve(PEN).round(0)
    lc, fc, tc = summarise(cur, PEN); lo, fo, to = summarise(x, PEN)
    print("\nOptimized allocation (shipments, penalty = 400 per late shipment):"); print(x.astype(int).to_string())
    print("\n%-22s %12s %14s %16s" % ("", "Exp. late", "Freight cost", "Cost + penalty"))
    print("%-22s %12.0f %14.0f %16.0f" % ("Current shares", lc, fc, tc))
    print("%-22s %12.0f %14.0f %16.0f" % ("LP optimized", lo, fo, to))
    print("Change: late shipments %.0f -> %.0f (%.1f%% fewer); total cost %.1f%% lower" % (lc, lo, 100 * (lc - lo) / lc, 100 * (tc - to) / tc))
    print("\nSensitivity to the assumed late-delivery penalty:")
    for p in [100, 200, 400, 800, 1600]:
        xp = solve(p); l2, f2, t2 = summarise(xp, p); l1, f1, t1 = summarise(cur, p)
        print("  penalty %5d: expected late %.0f -> %.0f | freight cost %.0f -> %.0f | total cost %.1f%% lower" % (p, l1, l2, f1, f2, 100 * (t1 - t2) / t1))
    return cur, x, plate, (lc, lo, tc, to)

# ---------- 8. Charts ----------
def save(fig, name):
    fig.tight_layout(); fig.savefig(name, dpi=170); plt.close(fig)

def charts(res, model, Xte, yte, imp, promise, cur, opt, stats):
    d = res.iloc[1:].copy()
    fig, ax = plt.subplots(figsize=(7, 3.4))
    allm = pd.concat([res.iloc[:1].assign(Model="Baseline\n(scheduled)"), d]).reset_index(drop=True)
    allm["Model"] = allm["Model"].str.replace(" ", "\n", n=1)
    bars = ax.bar(allm["Model"], allm["Test_MAE"], color=["#C55A11"] + ["#5B9BD5"] * len(d))
    ax.bar_label(bars, fmt="%.2f", padding=2); ax.set(title="Test MAE by model (days, lower is better)", ylabel="MAE (days)", ylim=(0, 0.8))
    save(fig, "fig1_model_mae.png")
    pred = model.predict(Xte)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.8))
    jit = np.random.default_rng(1).uniform(-.15, .15, len(yte))
    ax[0].scatter(yte + jit, pred, s=10, alpha=.35, color="#2E5597"); lim = [0, max(yte.max(), pred.max()) + 1]
    ax[0].plot(lim, lim, color="#C55A11", ls="--"); ax[0].set(title="Predicted vs actual days (tuned model)", xlabel="Actual days", ylabel="Predicted days")
    sns.histplot(yte - pred, bins=30, color="#5B9BD5", ax=ax[1]); ax[1].axvline(0, color="black", lw=1)
    ax[1].set(title="Prediction errors (actual - predicted)", xlabel="Error (days)", ylabel="Shipments")
    save(fig, "fig2_pred_actual.png")
    fig, ax = plt.subplots(figsize=(6.8, 3.6))
    top = imp.head(8)[::-1]; ax.barh(top.index, top.values, color="#2E5597"); ax.set(title="Permutation importance (rise in MAE when shuffled)", xlabel="Increase in MAE (days)")
    save(fig, "fig3_importance.png")
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.plot(promise["AvgPromise"], promise["OnTime"], marker="o", color="#2E5597")
    for _, r in promise.iterrows(): ax.annotate(f"{r.OnTime:.0f}%", (r.AvgPromise, r.OnTime), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=8)
    ax.set(title="Promise time vs on-time rate", xlabel="Average promised days", ylabel="On-time %", ylim=(40, 105))
    save(fig, "fig4_promise.png")
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.6), sharey=True)
    for a, plan, t in [(ax[0], cur, "Current shares"), (ax[1], opt, "LP optimized")]:
        plan.T.plot(kind="bar", stacked=True, ax=a, color=["#5B9BD5", "#9DC3E6", "#C55A11", "#A5A5A5"], width=.8, legend=a is ax[1])
        a.set(title=t, xlabel="", ylabel="Shipments per 1,000" if a is ax[0] else ""); a.tick_params(axis="x", rotation=0)
    save(fig, "fig5_allocation.png")

if __name__ == "__main__":
    df = prepare(simulate())
    X, y = df[CAT + NUM], df[TARGET]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=SEED)
    print("Rows: %d | train %d | test %d | target mean %.2f, std %.2f" % (len(df), len(Xtr), len(Xte), y.mean(), y.std()))
    res, fitted = compare_models(Xtr, ytr, Xte, yte)
    best = tune(Xtr, ytr, Xte, yte)
    imp = importance(best, Xte, yte)
    worked_example(best, Xte, yte)
    promise = promise_policy(best, Xtr, ytr, Xte, yte)
    cur, opt, plate, stats = carrier_allocation(df, Xtr, Xte)
    charts(res, best, Xte, yte, imp, promise, cur, opt, stats)
