# Logistics Data Analysis (Internship Project)

Python project for the Logistics Data Analyst Internship (Weeks 1 to 4).

| Week | Report | Code |
|---|---|---|
| 1 | Logistics_Week1_Strategic_Planning_Report.docx | pipeline_demo.py |
| 2 | Logistics_Week2_Data_Preparation_Report.docx | preprocess_demo.py |
| 3 | Logistics_Week3_Analysis_Visualization_Report.docx | analysis_demo.py |
| 4 | Logistics_Week4_Predictive_Modeling_Report.docx | model_demo.py |

## Week 4: Predictive modeling and optimization
Predicts shipment delivery time (days) for a simulated network of 6,000 shipments.
- Models compared with 5-fold cross-validation: Linear Regression, Decision Tree, Random Forest, Gradient Boosting, Gradient Boosting (MAE loss)
- Hyperparameter tuning with GridSearchCV (12 combinations x 5 folds)
- Tuned Gradient Boosting: test RMSE 0.902, R2 0.741 (baseline scheduled days: RMSE 1.072, R2 0.634)
- Optimization A: promise time = prediction + buffer raises on-time rate from 66.0% to 94.8%
- Optimization B: linear programming carrier allocation cuts expected late shipments from 349 to 308 per 1,000

## Run
```
pip install -r requirements.txt
python model_demo.py
```
`run_output.txt` is the console output of a full run. The script saves fig1 to fig5 as PNG images. Random seeds are fixed.

Note: all data is simulated, so results show the method, not the behaviour of a real company.
